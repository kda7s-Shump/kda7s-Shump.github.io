var app = new Vue({
  el: '#app',
  data: {
    product: "Socks",
    description: '岸和田高校の校長、中山玲代（なかやま　あきよ）と申します。',
    imageA: './assets/いっぬ-b.JPEG',
    imageB: './assets/いっぬ-g.JPG',
    imageC: './assets/いっぬ-pi.JPEG',
  }
})
